#ifndef API_H
#define API_H

#include "tecnicofs-api-constants.h"

#define SIZE 1024 

int tfsCreate(char *path, char nodeType);
int tfsLookup(char *path);
int tfsMove(char *from, char *to);
int tfsDelete(char *path);
int tfsPrint(char *outputfile);
int tfsMount(char* serverName);
int tfsUnmount();

#endif /* CLIENT_H */
