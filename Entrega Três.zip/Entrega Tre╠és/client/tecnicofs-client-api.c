#include "tecnicofs-client-api.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <string.h>
#include <sys/un.h>
#include <stdio.h>

#define CLEINTNAME "client"


char* serverName;
struct sockaddr_un serv_addr, client_addr;
int sockfd;
char client_name[SIZE];

int setSockAddrUn(char *path, struct sockaddr_un *addr){

  if (addr == NULL)
    return 0;

  bzero((char *)addr, sizeof(struct sockaddr_un));
  addr->sun_family = AF_UNIX;
  strcpy(addr->sun_path, path);

  return SUN_LEN(addr);
}


int tfsCreate(char *filename, char nodeType) {
  socklen_t servlen;
  char buffer[SIZE];
  char command[SIZE];

  /* Joins coomand into one  */
  sprintf(command,"c");
  sprintf(command + strlen(command)," %s",filename);
  sprintf(command + strlen(command), " %c", nodeType);
  
  servlen = setSockAddrUn(serverName, &serv_addr); 

  /* Sends command to server*/
  if (sendto(sockfd, command, strlen(command)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
    perror("client: sendto error\n");
    exit(EXIT_FAILURE);
  } 

  /* Receives answer */
  if (recvfrom(sockfd, buffer, sizeof(buffer), 0, 0, 0) < 0) {
    perror("client: recvfrom error");
    exit(EXIT_FAILURE);
  } 

  return atoi(&buffer[0]);
}

int tfsDelete(char *path) {
  socklen_t servlen;
  char buffer[SIZE];
  char command[SIZE];

  /* Joins coomand into one  */
  sprintf(command,"d");
  sprintf(command + strlen(command)," %s",path);


  servlen = setSockAddrUn(serverName, &serv_addr); 

  /* Sends command to server*/
  if (sendto(sockfd, command, strlen(command)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
    perror("client: sendto error\n");
    exit(EXIT_FAILURE);
  } 
  /* Receives answer */
  if (recvfrom(sockfd, buffer, sizeof(buffer), 0, 0, 0) < 0) {
    perror("client: recvfrom error");
    exit(EXIT_FAILURE);
  } 

  return atoi(&buffer[0]);
}

int tfsMove(char *from, char *to) {
  socklen_t servlen;
  char buffer[SIZE];
  char command[SIZE];

  /* Joins coomand into one  */
  sprintf(command,"m");
  sprintf(command + strlen(command)," %s",from);
  sprintf(command + strlen(command)," %s",to);

  servlen = setSockAddrUn(serverName, &serv_addr); 

  /* Sends command to server*/
  if (sendto(sockfd, command, strlen(command)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
    perror("client: sendto error\n");
    exit(EXIT_FAILURE);
  } 

  /* Receives answer */
  if (recvfrom(sockfd, buffer, sizeof(buffer), 0, 0, 0) < 0) {
    perror("client: recvfrom error");
    exit(EXIT_FAILURE);
  } 

  return atoi(&buffer[0]);

}

int tfsLookup(char *path) {
  socklen_t servlen;
  char buffer[SIZE];
  char command[SIZE];

  /* Joins coomand into one  */
  sprintf(command,"l");
  sprintf(command + strlen(command)," %s",path);

  servlen = setSockAddrUn(serverName, &serv_addr); 

  /* Sends command to server*/
  if (sendto(sockfd, command, strlen(command)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
    perror("client: sendto error\n");
    exit(EXIT_FAILURE);
  } 
  /* Receives answer */
  if (recvfrom(sockfd, buffer, sizeof(buffer), 0, 0, 0) < 0) {
    perror("client: recvfrom error");
    exit(EXIT_FAILURE);
  } 

  return atoi(&buffer[0]);
 
}

int tfsPrint(char *outputfile){
  socklen_t servlen;
  char command[SIZE];

  /* Joins coomand into one  */
  sprintf(command,"p");
  sprintf(command + strlen(command)," %s",outputfile);


  servlen = setSockAddrUn(serverName, &serv_addr); 

  /* Sends command to server */
  if (sendto(sockfd, command, strlen(command)+1, 0, (struct sockaddr *) &serv_addr, servlen) < 0) {
    perror("client: sendto error\n");
    exit(EXIT_FAILURE);
  } 
  return 0;
}


int tfsMount(char * sockPath) {
  int pid = getpid();
  socklen_t clilen;
  serverName = sockPath;
  strcpy(client_name,CLEINTNAME);
  sprintf(client_name + strlen(client_name),"%d",pid);


  if ((sockfd = socket(AF_UNIX, SOCK_DGRAM, 0) ) < 0) {
    perror("client: can't open socket");
    exit(EXIT_FAILURE);
  }

  unlink(client_name);

  clilen = setSockAddrUn (client_name, &client_addr);
  if (bind(sockfd, (struct sockaddr *) &client_addr, clilen) < 0) {
    perror("client: bind error");
    exit(EXIT_FAILURE);
  } 
  
  return 0;
}

int tfsUnmount() {
  
  unlink(client_name);

  close(sockfd);
  
  exit(EXIT_SUCCESS);
  return 0;
}


