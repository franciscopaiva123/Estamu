/* Sistemas Operativos 2020-21
   3ª Entrega 
   Francisco Paiva 96737
   Joao Rebolo 96748
*/

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <ctype.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "fs/threadprocess.h"
#include "fs/operations.h"
#include "tecnicofs-api-constants.h"


#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100


/* Number of threads */
int numberThreads = 0;

/* Name of server */
char* servername = NULL;

/*Socket variables*/
int sockfd;
socklen_t addrlen;
struct sockaddr_un client_addr;



void* applyCommands();


int setSockAddrUn(char *path, struct sockaddr_un *addr) {
  
  if (addr == NULL)return 0;

  bzero((char *)addr, sizeof(struct sockaddr_un));
  addr->sun_family = AF_UNIX;
  strcpy(addr->sun_path, path);

  return SUN_LEN(addr);
}


void *create_server(){
  /*int sockfd;*/
  struct sockaddr_un server_addr;
  /*socklen_t addrlen;*/

 if ((sockfd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
    perror("server: can't open socket");
    exit(EXIT_FAILURE);
  }

  unlink(servername);

  addrlen = setSockAddrUn(servername, &server_addr);
  if (bind(sockfd, (struct sockaddr *) &server_addr, addrlen) < 0) {
    perror("server: bind error");
    exit(EXIT_FAILURE);
  }

  while (1) {
    addrlen=sizeof(struct sockaddr_un);
    
    pthread_t* workers = (pthread_t*) malloc(numberThreads * sizeof(pthread_t)); 

    for(int i=0 ; i < numberThreads; i++){
        if (pthread_create(&workers[i], NULL, applyCommands, NULL) != 0){
            fprintf(stderr,"Can't create worker thread");
            exit(EXIT_FAILURE);
        }
    }
    /* Joins workers threads*/
    for(int i=0; i < numberThreads;i++){
        if(pthread_join(workers[i], NULL) != 0){
            fprintf(stderr,"Can't join worker thread");
            exit(EXIT_FAILURE);
        }
    }

  }
  return NULL;
  
}

/* Function that checks input writen in the terminal */
void parseArgs(long argc, char* const argv[]){
    if(argc != 3){
        fprintf(stderr, "Error: Number of arguments is incorrect\n");
        exit(EXIT_SUCCESS);
    }
    if(atoi(argv[1]) < 1){
        fprintf(stderr, "Error: Amount of threads is incorrect\n");
        exit(EXIT_SUCCESS);
    }
    /* Name of the server (global variable)*/
    servername = argv[2];
    
    /*Number of threads (global variable)*/
    numberThreads = atoi(argv[1]);
}

void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}


void* applyCommands(){
        while(1){
            int res;
            int c;
            char buffer[INDIM],out_buffer[OUTDIM];
            /*Recieves command from socket  */
            c = recvfrom(sockfd, buffer, sizeof(buffer)-1, 0,(struct sockaddr *)&client_addr, &addrlen);
            if (c <= 0) continue;
            //In case clinet doesnt end message with '\0', 
            buffer[c]='\0';

            char token;
            char type[MAX_INPUT_SIZE];
            char name[MAX_INPUT_SIZE];
            
            int numTokens = sscanf(buffer, "%c %s %s", &token, name, type);
            if (numTokens > 3) {
                fprintf(stderr, "Error: invalid command in Queue\n");
                exit(EXIT_FAILURE);
            }
            switch (token) {
                case 'c':
                    switch (type[0]){
                        case 'f':
                                res = create(name, T_FILE);
                                /* Sends output back to the client */
                                c = sprintf(out_buffer, "%d",res);
                                sendto(sockfd, out_buffer, c+1, 0, (struct sockaddr *)&client_addr, addrlen);
                                break;
                        case 'd':
                                res = create(name, T_DIRECTORY);
                                /* Sends output back to the client */
                                c = sprintf(out_buffer, "%d",res);
                                sendto(sockfd, out_buffer, c+1, 0, (struct sockaddr *)&client_addr, addrlen);
                                break;
                            
                        default:
                                fprintf(stderr, "Error: invalid node type\n");
                                exit(EXIT_FAILURE);
                    }
                    break;
                case 'l':
                        res = lookup_main(name); 
                        if(res >= 0) printf("Search: %s found\n", name);
                        else(printf("Search: %s not found\n", name));
                        /* Sends output back to the client */
                        c = sprintf(out_buffer, "%d",res);
                        sendto(sockfd, out_buffer, c+1, 0, (struct sockaddr *)&client_addr, addrlen);
                        break;

                case 'd':
                        res = delete(name);
                        /* Sends output back to the client */
                        c = sprintf(out_buffer, "%d",res);
                        sendto(sockfd, out_buffer, c+1, 0, (struct sockaddr *)&client_addr, addrlen);
                        break;
                case 'm':
                        res = move(name,type);
                        /* Sends output back to the client */
                        c = sprintf(out_buffer, "%d",res);
                        sendto(sockfd, out_buffer, c+1, 0, (struct sockaddr *)&client_addr, addrlen);
                        break;
                case 'p':
                        print_tecnicofs_tree(name);
                        break;
                default: /* error */
                        fprintf(stderr, "Error: command to apply\n");
                        exit(EXIT_FAILURE);                   
            }
        }
}

int main(int argc, char* argv[]) {
    
    parseArgs(argc, argv);

    /* initiate filesystem */
    init_fs();

    /* initiate global rwlock for print_tecnicofs_tree */
    init_global();

    /*Creates socket */
    create_server();

    /* release allocated memory */
    destroy_fs();

    exit(EXIT_SUCCESS);
}
